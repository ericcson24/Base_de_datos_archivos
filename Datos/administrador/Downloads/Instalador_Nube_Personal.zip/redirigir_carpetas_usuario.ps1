$usuario = $env:USERNAME
$destino = "C:\NubeDistribuible_v2\Datos\$usuario"

Write-Host "Redirigiendo carpetas de usuario a: $destino" -ForegroundColor Cyan

$knownFolders = @{
  'Desktop' = 'Escritorio'
  'Documents' = 'Documentos'
  'Downloads' = 'Descargas'
  'Pictures' = 'Imágenes'
  'Music' = 'Música'
  'Videos' = 'Vídeos'
}

foreach ($key in $knownFolders.Keys) {
  $nombreCarpeta = $knownFolders[$key]
  $ruta = "$destino\$nombreCarpeta"
  New-Item -ItemType Directory -Force -Path $ruta | Out-Null
  [Environment]::GetFolderPath("My" + $key) | ForEach-Object {
    $shell = New-Object -ComObject Shell.Application
    $folder = $shell.NameSpace($_)
    if ($folder) {
      $folder.Self.Path = $ruta
    }
  }
}

Write-Host "✅ Carpetas redirigidas con éxito." -ForegroundColor Green
pause
