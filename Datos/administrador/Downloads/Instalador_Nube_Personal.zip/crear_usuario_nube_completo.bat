@echo off
title Crear nuevo usuario en el servidor de nube
color 0A
echo ================================================
echo       CREAR USUARIO PARA NUBE PERSONAL
echo ================================================
set /p usuario=Introduce el nombre del nuevo usuario: 
set /p clave=Introduce la contraseña (mínimo 8 caracteres, con mayúsculas y número): 

echo.
echo ✅ Creando usuario Windows y activando RDP...
net user %usuario% %clave% /add
net localgroup "Usuarios de escritorio remoto" %usuario% /add

echo.
echo ✅ Creando carpeta de datos en C:\NubeDistribuible_v2\Datos\%usuario%
mkdir "C:\NubeDistribuible_v2\Datos\%usuario%"

echo.
echo ✅ Copiando script de enlace y redirección al escritorio de %usuario%
copy "vincular_carpeta_desde_escritorio.bat" "C:\Users\%usuario%\Desktop\"
copy "redirigir_carpetas_usuario.ps1" "C:\Users\%usuario%\Desktop\"

echo.
echo ✅ Todo listo. Al entrar, el usuario debe ejecutar el script para redirigir sus carpetas.
pause
