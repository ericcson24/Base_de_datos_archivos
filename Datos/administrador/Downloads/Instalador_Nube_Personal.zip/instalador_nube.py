
import os
import subprocess
import ctypes

def es_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def main():
    print("🚀 Instalador de Usuario Nube Personal")
    print("--------------------------------------")

    if not es_admin():
        print("❌ Este instalador necesita privilegios de administrador.")
        input("Presiona ENTER para salir...")
        return

    print("✅ Ejecutando script de creación de usuario...")
    subprocess.call("crear_usuario_nube_completo.bat", shell=True)

if __name__ == "__main__":
    main()
