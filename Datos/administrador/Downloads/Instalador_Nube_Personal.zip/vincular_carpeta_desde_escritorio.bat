@echo off
title Vincular carpeta de nube
color 0B
echo ===============================
echo     ENLACE A TU NUBE PERSONAL
echo ===============================

mklink /D "%USERPROFILE%\Desktop\ArchivosNube" "C:\NubeDistribuible_v2\Datos\%USERNAME%"

echo.
echo ✅ Acceso directo creado en el escritorio como "ArchivosNube".
pause
