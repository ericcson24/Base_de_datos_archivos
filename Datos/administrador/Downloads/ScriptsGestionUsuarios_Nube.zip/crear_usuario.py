
import os
import subprocess
import ctypes

def es_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def main():
    if not es_admin():
        print("❌ Debes ejecutar este programa como administrador.")
        input("Presiona ENTER para salir...")
        return

    print("🧑 Crear nuevo usuario")
    usuario = input("Nombre del nuevo usuario: ")
    clave = input("Contraseña (mínimo 8 caracteres, con mayúsculas y número): ")

    os.system(f'net user {usuario} {clave} /add')
    os.system(f'net localgroup "Usuarios de escritorio remoto" {usuario} /add')
    os.makedirs(f'C:\\NubeDistribuible_v2\\Datos\\{usuario}', exist_ok=True)

    # Copiar scripts al escritorio del nuevo usuario
    origen = os.getcwd()
    destino = f'C:\\Users\\{usuario}\\Desktop'
    os.system(f'copy "{origen}\\vincular_carpeta_desde_escritorio.bat" "{destino}"')
    os.system(f'copy "{origen}\\redirigir_carpetas_usuario.ps1" "{destino}"')

    print("✅ Usuario creado y preparado para la nube.")
    input("Presiona ENTER para finalizar.")

if __name__ == "__main__":
    main()
